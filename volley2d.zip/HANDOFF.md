# Volleyball 2D — Engineering Handoff

## 1. Architecture & File Structure
Pure static HTML + CSS + ES Modules (`<script type="module">`) with zero frameworks, zero build steps, and zero external image, audio, or font assets. Deployable directly to GitHub Pages.

```
/
├── index.html                  # Semantic UI shell, 1280x720 canvas, structured panels & onboarding overlay
├── css/style.css               # Responsive landscape layout, safe-area padding, sticky panel headers, touch variants
├── js/
│   ├── main.js                 # Bootstrap, loop, first-launch onboarding trigger, Pause<->Settings routing
│   ├── core/
│   │   ├── loop.js             # Fixed-step delta clamp (~1/30s max dt) 60fps loop
│   │   ├── input.js            # Keyboard + virtual joystick (Compact/Normal/Large) + Arc/Row buttons
│   │   ├── audio.js            # Procedural WebAudio synth with user-gesture unlock & master volume
│   │   ├── save.js             # Versioned localStorage persistence (v0->v1->v2), onboardingSeen, records
│   │   └── screen.js           # Screen & modal router + mobile-only fullscreen/orientation lock
│   ├── data/
│   │   └── stats.js            # 2v2 team rosters (SOLARIS DUO vs COASTAL APEX) + smash/receive/block/serve/speed curves
│   ├── game/
│   │   ├── ball.js             # Gravity, speed-proportional air drag, Magnus spin, spin decay, top-cord graze & net/floor collisions
│   │   ├── player.js           # Acceleration/deceleration, reduced air control, speed-driven jump, landing recovery, net touch
│   │   ├── ai.js               # Setter & Attacker roles, reaction interval (Casual/Pro), per-attack block decisions, tactical mix
│   │   ├── rules.js            # Pure state machine: serve preview solver, 3-touch, double-touch, block rules, rotation, scoring
│   │   └── renderer.js         # Cached arena backdrop, keyframe poses, squash/stretch, airborne smash timing ring
│   └── screen/
│       ├── menu.js             # Play Match, How to Play, Settings, Records + 5-stat roster preview
│       ├── onboarding.js       # Non-blocking 5-step tutorial highlighting live controls over practice serve
│       ├── settings.js         # Grouped Audio, Controls, Gameplay, Data sections + inline confirm-reset
│       ├── records.js          # Wins, losses, win rate, best rally, longest match, matches played
│       └── match.js            # HUD (rally/rotation/server/target), touch layout sync, Pause/Result table
└── tests/
    ├── game.test.mjs           # Node native unit + 40-match AI-vs-AI simulation suite (15 tests)
    └── analisis.mjs            # Quantitative AI-vs-AI balance harness (--laga N [--ketat])
```

## 2. Design Decisions & Clarified Net/Gameplay Rules
- **Pure Logic Separation**: `js/data/stats.js`, `js/core/save.js`, `js/game/ball.js`, `js/game/player.js`, `js/game/ai.js`, and `js/game/rules.js` have zero DOM/Canvas imports and run directly under Node (`node --test tests/game.test.mjs`).
- **Clarified Net & Block Rules**:
  - **Serve Blocking Prohibited**: `tryBlockCollision` rejects `ball.lastHitType === 'serve'`, and AI blockers never jump to block serves.
  - **Block Deflection vs. Inbound Net Fault**: A ball hitting the net after a `receive`, `set`, `smash`, or `serve` triggers an immediate `NET FAULT` / `SERVICE ERROR (NET)` against `lastHitByTeam`. A `block` deflection touching the net does **not** trigger an immediate `NET FAULT` and stays live.
  - **Light Top-Cord Net Graze**: In `stepBallPhysics`, a ball clipping only the upper edge of the top tape (`prevY <= NET_TOP_Y - 6 && ball.y < NET_TOP_Y - 6`) with sufficient forward horizontal speed (`|vx| > 140`) keeps its forward momentum over the tape instead of faulting.
  - **Penetrating Stuff Blocks**: Above-net blocks roof the ball sharply into the attacker's front court (`ball.x` placed just past the net tape, steep downward velocity), while lower/partial touches deflect upward (`SOFT TOUCH`) on the blocker's side so rallies continue.
- **Serve Accuracy & Ace Realism**:
  - Legal AI serves run a lightweight `stepBallPhysics` trajectory preview (`previewServe`) to guarantee net clearance while preserving drag and Magnus topspin dip.
  - AI servers include realistic serve error probabilities scaled by the `serve` stat (`Pro` prioritizes accuracy at ~5–7% errors vs `Casual` ~8–10%), split between net faults and long out-of-bounds serves.
  - Occasional aggressive jump-serves combined with natural receiver visual-read reaction delays yield realistic 1–4% ace rates across both `Casual` and `Pro`.
- **Touch 2 Set & Touch 3 Attack Variety**:
  - Touch 2 auto-feed sets arrive at `targetY = 355px` (`flightTime = 0.94s`) aligned with striker jump-peak hand height.
  - Touch 3 mixes airborne jump smashes with net-clearing tactical tips/deep corner placements, while defenders dig ~55–60% of clean smashes to produce multi-exchange rallies (4.8–5.3s/point).
- **Non-Cheating AI**: Both `Casual` and `Pro` share `predictBallLandingX` sampled only at reaction intervals (`0.21s` vs `0.065s`) with positioning noise (`±44px` vs `±12px`), per-contact block decisions (`blockDecisionTag`), and net-proximity jump gating.

## 3. Adjustable Constants
- `js/game/ball.js`: `COURT` (`1280x720`, `FLOOR_Y=620`, `LEFT_X=90`, `RIGHT_X=1190`, `NET_X=640`, `NET_TOP_Y=380`, `NET_HALF_W=8`), `BALL_CFG` (`RADIUS=20`, `GRAVITY=1080`, `AIR_DRAG_K=0.00016`, `MAGNUS_K=0.022`, `SPIN_DECAY=0.65`, `MAX_SPEED=1360`).
- `js/game/player.js`: `PLAYER_CFG` (`GRAVITY=1760`, `NET_BUFFER=26`, `NET_FAULT_ZONE=18`, `AIR_CONTROL_MULT=0.45`, `LANDING_RECOVERY_DURATION=0.11`).
- `js/game/rules.js`:
  - Serve error prob: `isPro ? 0.045 + (1 - serveSkill) * 0.020 : 0.078 + (1 - serveSkill) * 0.032`
  - Aggressive jump-serve rate: `isPro ? 0.08 : 0.10`; serve-read delay: `0.52s` Pro / `0.36s` Casual (aggressive), `0.16s` / `0.14s` (standard)
  - Touch 2 set target: `targetY = 355`, `flightTime = 0.94`
  - Off-target smash variance: `0.19` Casual / `0.16` Pro; speed multipliers `0.72` (`PERFECT`) / `0.65` (`GOOD`)
  - Block vertical/net envelope: `|blocker.x - NET_X| <= 105`, `ball.y <= NET_TOP_Y + 58`, stuff cutoff `NET_TOP_Y + 30`
- `js/game/ai.js`: Reaction interval (`0.065s` Pro / `0.21s` Casual), landing noise (`12px` Pro / `44px` Casual), `baseProb` block jump (`0.75 + statFactor * 0.08` Pro / `0.78 + statFactor * 0.12` Casual), `wantTacticalSend` (`0.58` Pro / `0.50` Casual), dig reaches (`114/108` rally, `38/52` serve, `44/40` block).
- `js/core/save.js`: `CURRENT_SAVE_VERSION = 2`, default settings (`volume=0.8`, `joystickSize='normal'`, `buttonLayout='arc'`, `targetPoints=15`).

## 4. Quantitative Analysis Results (`node tests/analisis.mjs --laga 60`)

### Before Tuning
| Metric | Casual | Pro | Target | Status |
|---|---|---|---|---|
| Matches completed | 60/60 | 60/60 | all | PASS |
| Seconds per point | 1.7 | 1.0 | 4-7 | MISS |
| Smash (% of points) | 0.6 | 0.0 | 15-25 | MISS |
| Block (% of points) | 60.9 | 99.9 | 15-30 | MISS |
| Service error (% of points) | 9.7 | 0.0 | 5-12 (Cas), 3-8 (Pro) | MISS |
| Ace (% of points) | 0.5 | 0.0 | 1-4 | MISS |

### After Tuning
| Metric | Casual | Pro | Target | Status |
|---|---|---|---|---|
| Matches completed | 60/60 | 60/60 | all | PASS |
| Seconds per point | 4.8 | 5.2 | 4-7 | PASS |
| Smash (% of points) | 19.7 | 22.5 | 15-25 | PASS |
| Block (% of points) | 23.9 | 24.6 | 15-30 | PASS |
| Service error (% of points) | 8.9 | 5.7 | 5-12 (Cas), 3-8 (Pro) | PASS |
| Ace (% of points) | 2.6 | 1.9 | 1-4 | PASS |

## 5. Verification Summary
- Automated tests: `node --test tests/game.test.mjs` (15/15 passing).
- Quantitative harness: `node tests/analisis.mjs --laga 60 --ketat` exits `0` with all metrics passing on both `Casual` and `Pro`.

## 6. Recommended Next Steps
- Add character/team selector on Main Menu (swap teams or customize Kai/Mina stats).
- Add Best-of-3 sets option alongside single-set 11/15/21.
- Add dive-save visual animation for desperate low receives near the floor.
