// Role-based 2v2 AI (Setter & Attacker) with reaction delay, no future-cheating, and Casual mistakes (no DOM dependencies)

import { COURT, predictBallLandingX } from './ball.js';

export function createAiMemory() {
  return {
    reactionTimer: 0,
    estimatedLandingX: COURT.NET_X + 240,
    noiseOffset: 0,
    wantNetMistake: false,
    blockDecisionTag: '',
    wantBlockJump: false,
    attackDecisionTag: '',
    wantTacticalSend: false,
  };
}

function updateEstimate(aiMem, ball, difficulty, dt, blockStat = 75) {
  const isPro = difficulty === 'pro';
  const interval = isPro ? 0.065 : 0.21;
  aiMem.reactionTimer -= dt;
  if (aiMem.reactionTimer <= 0) {
    aiMem.reactionTimer = interval;
    const rawEst = predictBallLandingX(ball);
    const maxNoise = isPro ? 12 : 44;
    aiMem.noiseOffset = (Math.random() - 0.5) * 2 * maxNoise;
    aiMem.estimatedLandingX = rawEst + aiMem.noiseOffset;
    aiMem.rawLandingX = rawEst;
    aiMem.wantNetMistake = !isPro && Math.random() < 0.03;
  }

  // Reset per-contact AI decisions whenever ball changes hitter/type
  const tag = `${ball.lastHitByTeam}:${ball.lastHitById}:${ball.lastHitType}`;
  if (aiMem.blockDecisionTag !== tag) {
    aiMem.blockDecisionTag = tag;
    const statFactor = Math.max(0, Math.min(1, (blockStat - 50) / 50));
    const baseProb = isPro ? 0.75 + statFactor * 0.08 : 0.78 + statFactor * 0.12;
    aiMem.wantBlockJump = ball.lastHitType !== 'serve' && Math.random() < baseProb;
  }
  if (aiMem.attackDecisionTag !== tag) {
    aiMem.attackDecisionTag = tag;
    // Mix jump smashes with tactical roll-shots / deep lobs / tips
    aiMem.wantTacticalSend = ball.lastHitType === 'set' && Math.random() < (isPro ? 0.58 : 0.50);
  }
}

// Home AI (Setter / Support for human player, or full 2v2 AI when aiControlledHome=true)
export function computeTeammateControl(teammate, partner, ball, match, aiMem, dt, isFullAiSlot0 = false) {
  if (aiMem) updateEstimate(aiMem, ball, match.difficulty, dt, teammate.stats?.block);
  const estLandingX = aiMem ? aiMem.estimatedLandingX : predictBallLandingX(ball);
  const isPro = match.difficulty === 'pro';
  const isAiTeam = isFullAiSlot0 || match.aiControlledHome;

  let targetX = teammate.slotIndex === 0 ? 310 : 465;
  let jumpPressed = false;
  let wantAction = false;
  let wantSmash = false;

  if (match.phase === 'serve_wait') {
    const isHomeServer = match.servingTeam === 'home' && teammate.slotIndex === match.homeServerIndex;
    targetX = isHomeServer ? COURT.LEFT_X - 32 : (teammate.slotIndex === 0 ? 305 : 475);
    return {
      moveX: steerToward(teammate.x, targetX),
      jumpPressed: false,
      jumpHeld: false,
      wantAction: false,
      wantSmash: false,
    };
  }

  const ownServeInFlight = ball.lastHitType === 'serve' && ball.lastHitByTeam === 'home';
  const ballOnHomeSide = (ball.vx < 0 || ball.x < COURT.NET_X) && !ownServeInFlight;
  const canTouch =
    match.possessionSide !== 'home' ||
    match.lastTouchingPlayerId !== teammate.id ||
    match.lastTouchWasBlock;

  if (ballOnHomeSide && canTouch) {
    if (match.sideTouches === 1 && match.lastTouchingPlayerId === partner.id) {
      // Touch 2: Teammate who did NOT receive Touch 1 sets the Auto-Feed!
      targetX = clampHomeX(estLandingX);
      const dist = Math.hypot(ball.x - teammate.x, ball.y - (teammate.y - 64));
      if (ball.x < COURT.NET_X - 8 && dist < 104 && ball.vy > -190) {
        wantAction = true;
      }
    } else if (isAiTeam && match.sideTouches === 2) {
      // Touch 3: Mix jump smashes with tactical placement roll-shots / tips
      const tacticalMode = Boolean(aiMem?.wantTacticalSend);
      if (tacticalMode) {
        targetX = clampHomeX(estLandingX);
        const dist = Math.hypot(ball.x - teammate.x, ball.y - (teammate.y - 58));
        if (ball.x < COURT.NET_X - 8 && dist < 102 && ball.vy > -120) {
          wantAction = true;
        }
      } else {
        const hitOffset = isPro ? 14 : 24;
        targetX = clampHomeX(ball.x - hitOffset);
        const lateWindow = isPro ? 415 : 445;
        if (
          Math.abs(ball.x - teammate.x) < 70 &&
          teammate.onGround &&
          ball.y > 160 &&
          ball.y < lateWindow &&
          ball.vy > -180
        ) {
          jumpPressed = true;
        }
        if (!teammate.onGround && Math.hypot(ball.x - teammate.x, ball.y - (teammate.y - 84)) < 98) {
          wantSmash = true;
        } else if (teammate.onGround && ball.y > 460 && Math.hypot(ball.x - teammate.x, ball.y - (teammate.y - 54)) < 100) {
          wantAction = true;
        }
      }
    } else if (match.sideTouches === 0) {
      // Touch 1: Closer player receives incoming ball (let clear out-of-bounds balls drop)
      const rawEstX = aiMem?.rawLandingX ?? estLandingX;
      const clearlyOut = rawEstX < COURT.LEFT_X - 18 || rawEstX > COURT.RIGHT_X + 18;
      const distSelf = Math.abs(estLandingX - teammate.x);
      const distPartner = Math.abs(estLandingX - partner.x);
      const tieBias = isAiTeam ? (teammate.slotIndex === 1 ? -14 : 14) : 24;
      if (!clearlyOut && distSelf <= distPartner + tieBias) {
        targetX = clampHomeX(estLandingX);
        const digReach =
          ball.lastHitType === 'block' ? (isPro ? 44 : 40) :
          ball.lastHitType === 'serve' ? (isPro ? 38 : 52) :
          (isPro ? 114 : 108);
        const dist = Math.hypot(ball.x - teammate.x, ball.y - (teammate.y - 52));
        if (ball.x < COURT.NET_X - 6 && dist < digReach && ball.vy > -80) {
          wantAction = true;
        }
      } else {
        targetX = partner.x > 420 ? 310 : 485;
      }
    } else {
      targetX = partner.x > 420 ? 310 : 485;
    }
  } else if (isAiTeam && ball.x >= COURT.NET_X) {
    // Ball on Away side: Front-court player covers net block ONLY for real attacks (not serves)
    if (teammate.slotIndex === 0) {
      targetX = COURT.NET_X - 46;
      const awayJumpingToAttack =
        ball.lastHitType !== 'serve' &&
        match.possessionSide === 'away' &&
        match.sideTouches === 2 &&
        match.awayPlayers.some((p) => !p.onGround && p.vy > -180 && p.x < COURT.NET_X + 215);
      const awaySmashInbound =
        ball.lastHitType === 'smash' && ball.vx < -160 && ball.x < COURT.NET_X + 220;

      if (
        (awayJumpingToAttack || awaySmashInbound) &&
        Math.abs(teammate.x - COURT.NET_X) < 76 &&
        aiMem?.wantBlockJump &&
        teammate.onGround
      ) {
        jumpPressed = true;
        aiMem.wantBlockJump = false;
      }
    } else {
      targetX = isPro ? 345 : 330;
    }
  } else {
    targetX = isFullAiSlot0 ? 340 : 460;
  }

  return {
    moveX: steerToward(teammate.x, targetX),
    jumpPressed,
    jumpHeld: jumpPressed || !teammate.onGround,
    wantAction,
    wantSmash,
  };
}

// Opponent Away AI with explicit Setter (non-receiver) and Attacker roles
export function computeOpponentControl(player, partner, ball, match, difficulty = 'casual', aiMem = null, dt = 1 / 60) {
  if (aiMem) updateEstimate(aiMem, ball, difficulty, dt, player.stats?.block);

  const isPro = difficulty === 'pro';
  const speedScale = isPro ? 1.0 : 0.88;
  const estLandingX = aiMem ? aiMem.estimatedLandingX : predictBallLandingX(ball);
  const netFaultLunge = Boolean(aiMem?.wantNetMistake);

  let targetX = player.slotIndex === 0 ? 780 : 950;
  let jumpPressed = false;
  let wantReceive = false;
  let wantSmash = false;

  if (match.phase === 'serve_wait') {
    if (match.servingTeam === 'away' && player.slotIndex === match.awayServerIndex) {
      targetX = COURT.RIGHT_X + 32;
    } else {
      targetX = player.slotIndex === 0 ? 785 : 965;
    }
    return {
      moveX: steerToward(player.x, targetX) * speedScale,
      jumpPressed: false,
      jumpHeld: false,
      wantReceive: false,
      wantSmash: false,
      allowNetLunge: false,
    };
  }

  const ownServeInFlight = ball.lastHitType === 'serve' && ball.lastHitByTeam === 'away';
  const ballOnAwaySide = (ball.vx > 0 || ball.x >= COURT.NET_X) && !ownServeInFlight;
  const canTouch =
    match.possessionSide !== 'away' ||
    match.lastTouchingPlayerId !== player.id ||
    match.lastTouchWasBlock;

  if (ballOnAwaySide) {
    // Never jump to block a serve! Only block an incoming Home attack near the net
    const homeAttackingAtNet =
      ball.lastHitType !== 'serve' &&
      player.slotIndex === 0 &&
      ball.x < COURT.NET_X &&
      ball.x > COURT.NET_X - 210 &&
      ball.vx > 140 &&
      ball.y < COURT.NET_TOP_Y + 45;

    if (homeAttackingAtNet) {
      targetX = netFaultLunge ? COURT.NET_X + 12 : COURT.NET_X + 46;
      if (Math.abs(player.x - COURT.NET_X) < 76 && aiMem?.wantBlockJump && player.onGround) {
        jumpPressed = true;
        aiMem.wantBlockJump = false;
      }
    } else if (match.possessionSide === 'away' && match.sideTouches === 1) {
      // Touch 2: Teammate who did NOT touch Touch 1 acts as Setter!
      if (canTouch) {
        targetX = clampAwayX(estLandingX);
        const dist = Math.hypot(ball.x - player.x, ball.y - (player.y - 64));
        if (ball.x >= COURT.NET_X + 8 && dist < 104 && ball.vy > -190) {
          wantReceive = true;
        }
      } else {
        targetX = 765;
      }
    } else if (match.possessionSide === 'away' && match.sideTouches === 2) {
      // Touch 3: Mix jump smashes with tactical placement roll-shots / tips
      if (canTouch) {
        const tacticalMode = Boolean(aiMem?.wantTacticalSend);
        if (tacticalMode) {
          targetX = clampAwayX(estLandingX);
          const dist = Math.hypot(ball.x - player.x, ball.y - (player.y - 58));
          if (ball.x >= COURT.NET_X + 8 && dist < 102 && ball.vy > -120) {
            wantReceive = true;
          }
        } else {
          targetX = clampAwayX(ball.x + (isPro ? 14 : 24));
          const horizClose = Math.abs(ball.x - player.x) < 70;
          const lateWindow = isPro ? 415 : 445;
          if (horizClose && player.onGround && ball.y > 160 && ball.y < lateWindow && ball.vy > -180) {
            jumpPressed = true;
          }
          if (!player.onGround && Math.hypot(ball.x - player.x, ball.y - (player.y - 84)) < 98) {
            wantSmash = true;
          } else if (player.onGround && ball.y > 460 && Math.hypot(ball.x - player.x, ball.y - (player.y - 54)) < 100) {
            wantReceive = true;
          }
        }
      } else {
        targetX = 950;
      }
    } else {
      // Touch 0: Receive incoming ball (let clear out-of-bounds balls drop)
      const rawEstX = aiMem?.rawLandingX ?? estLandingX;
      const clearlyOut = rawEstX < COURT.LEFT_X - 18 || rawEstX > COURT.RIGHT_X + 18;
      const distSelf = Math.abs(estLandingX - player.x);
      const distPartner = Math.abs(estLandingX - partner.x);
      const isCloser = distSelf <= distPartner + (player.slotIndex === 1 ? -14 : 14);
      if (!clearlyOut && isCloser && canTouch) {
        targetX = clampAwayX(estLandingX);
        const digReach =
          ball.lastHitType === 'block' ? (isPro ? 44 : 40) :
          ball.lastHitType === 'serve' ? (isPro ? 38 : 52) :
          (isPro ? 114 : 108);
        const dist = Math.hypot(ball.x - player.x, ball.y - (player.y - 52));
        if (ball.x >= COURT.NET_X + 6 && dist < digReach && ball.vy > -80) {
          wantReceive = true;
        }
      } else {
        targetX = player.slotIndex === 0 ? 785 : 950;
      }
    }
  } else {
    // Ball on Home side: Blocker tracks net and jumps with Home attacker; Defender covers mid-backcourt
    if (player.slotIndex === 0) {
      targetX = COURT.NET_X + 46;
      const homeJumpingToAttack =
        ball.lastHitType !== 'serve' &&
        match.possessionSide === 'home' &&
        match.sideTouches === 2 &&
        match.homePlayers.some((p) => !p.onGround && p.vy > -180 && p.x > COURT.NET_X - 215);
      const homeSmashInbound =
        ball.lastHitType === 'smash' && ball.vx > 160 && ball.x > COURT.NET_X - 220;

      if (
        (homeJumpingToAttack || homeSmashInbound) &&
        Math.abs(player.x - COURT.NET_X) < 76 &&
        aiMem?.wantBlockJump &&
        player.onGround
      ) {
        jumpPressed = true;
        aiMem.wantBlockJump = false;
      }
    } else {
      targetX = isPro ? 935 : 950;
    }
  }

  return {
    moveX: steerToward(player.x, targetX) * speedScale,
    jumpPressed,
    jumpHeld: jumpPressed || !player.onGround,
    wantReceive,
    wantSmash,
    allowNetLunge: netFaultLunge,
  };
}

function steerToward(currentX, targetX) {
  const diff = targetX - currentX;
  if (Math.abs(diff) < 10) return 0;
  return Math.max(-1, Math.min(1, diff / 42));
}

function clampHomeX(x) {
  return Math.max(COURT.LEFT_X + 24, Math.min(COURT.NET_X - 36, x));
}

function clampAwayX(x) {
  return Math.max(COURT.NET_X + 36, Math.min(COURT.RIGHT_X - 24, x));
}
